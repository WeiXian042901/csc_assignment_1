const Clarifai = require('clarifai');

const app = new Clarifai.App({
    apiKey: 'b3e4003595fe48c2b8279bae821519fe',
});

app.inputs
    .create([
        {
            url:
                'https://lh3.googleusercontent.com/-OJQe8W6aLYF2BLCl9yAQt6-8VL11CEA7anLcvyaIhBjj2vG5PxiR5opojvqh0uI3PtK=s85',
            concepts: [
                {
                    id: 'receipt',
                    value: true,
                },
            ],
        },
        // {
        //     url:
        //         'https://cdn.filestackcontent.com/iYfZsZ8mSEWP85T8gHve/convert?cache=true&crop=0%2C0%2C1920%2C960&crop_first=true&h=300&w=450',
        //     concepts: [
        //         {
        //             id: 'receipt',
        //             value: true,
        //         },
        //     ],
        // },
        // {
        //     url: 'https://sga.sa.ua.edu/wp-content/uploads/sites/28/2019/10/Walmart-Receipt.jpg',
        //     concepts: [
        //         {
        //             id: 'receipt',
        //             value: true,
        //         },
        //     ],
        // },
        // {
        //     url: 'https://expensefast.com/wp-content/uploads/2020/05/lowes-hardware-receipt-template-341x1024.jpg',
        //     concepts: [
        //         {
        //             id: 'receipt',
        //             value: true,
        //         },
        //     ],
        // },
        // {
        //     url: 'https://i.pinimg.com/736x/88/30/be/8830be16c023b48327020d96a9b471d1.jpg',
        //     concepts: [
        //         {
        //             id: 'receipt',
        //             value: true,
        //         },
        //     ],
        // },
        // {
        //     url: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTRWyzjqIf2sourOWQbKohGUONvdTp89Yxeew&usqp=CAU',
        //     concepts: [
        //         {
        //             id: 'receipt',
        //             value: true,
        //         },
        //     ],
        // },
        // {
        //     url:
        //         'https://ca-times.brightspotcdn.com/dims4/default/e940ccd/2147483647/strip/true/crop/2530x3385+0+0/resize/840x1124!/quality/90/?url=https%3A%2F%2Fcalifornia-times-brightspot.s3.amazonaws.com%2Fd8%2Fa1%2F210af1444ee5bcdbbe1823c91c24%2F0430-china-chef-receipt-edited-jpg.jpg',
        //     concepts: [
        //         {
        //             id: 'receipt',
        //             value: true,
        //         },
        //     ],
        // },
        // {
        //     url:
        //         'https://bloximages.chicago2.vip.townnews.com/gvnews.com/content/tncms/assets/v3/editorial/b/f7/bf7d9292-08fd-11e6-83f7-13be467b670c/571ae2e5a8aac.image.jpg?resize=500%2C1051',
        //     concepts: [
        //         {
        //             id: 'receipt',
        //             value: true,
        //         },
        //     ],
        // },
        // {
        //     url: 'https://i0.wp.com/www.dailycal.org/assets/uploads/2014/03/receipt.jpg?ssl=1',
        //     concepts: [
        //         {
        //             id: 'receipt',
        //             value: true,
        //         },
        //     ],
        // },
    ])
    .then(
        function (response) {
            console.log(response);
        },
        function (err) {
            console.log(err);
        },
    );

// app.models.create('receipt', [{ id: 'receipt' }]).then(
//     function (response) {
//         console.log(response);
//     },
//     function (err) {
//         console.log(err);
//     },
// );

// app.models.train('receipt').then(
//     function (response) {
//         console.log(response.rawData);
//     },
//     function (err) {
//         console.log(err);
//     },
// );

// app.inputs.search({ concept: { name: 'receipt' } }).then(
//     function (response) {
//         response.hits.forEach((hit) => {
//             console.log('this is the score:', hit.score);
//             console.log(hit.input.data.image);
//         });
//     },
//     function (err) {
//         console.log(err);
//     },
// );
