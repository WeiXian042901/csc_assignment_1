let clarifaiApiKey = 'b3e4003595fe48c2b8279bae821519fe';
let workflowId = null;
let imageData = null;
let isReceipt = false;

let app = new Clarifai.App({
    apiKey: clarifaiApiKey,
});

$(function () {
    $('#uploadBtn').on('click', (e) => {
        reset();
        $('#loading').show();

        let preview = document.querySelector('img');
        let file = document.querySelector('input[type=file]').files[0];
        if (file !== undefined) {
            let fileType = file['type'];
            const validImageTypes = ['image/gif', 'image/jpeg', 'image/png', 'image/svg'];
            if (!validImageTypes.includes(fileType)) {
                $('#loading').hide();
                alert('Upload a file!');
            } else {
                let reader = new FileReader();

                reader.addEventListener(
                    'load',
                    function () {
                        preview.src = reader.result;
                        imageData = reader.result;
                        imageData = imageData.replace(/^data:image\/(.*);base64,/, '');
                        app.models
                            .initModel({
                                id: 'receipt-recognition',
                                version: '5d0580d91c7f4fdf9211c943f32924ca',
                            })
                            .then((generalModel) => {
                                return generalModel.predict(imageData);
                            })
                            .then(
                                function (response) {
                                    let concepts = response['outputs'][0]['data']['concepts'];
                                    if (concepts[0].value > 0.5) {
                                        isReceipt = true;
                                        uploadImagewTag(imageData);
                                        $('.analysis').html('<h1> It is probably a receipt. </h1>');
                                    } else $('.analysis').html('<h1> It is probably not a receipt. </h1>');

                                    preview.src = reader.result;
                                    $('#loading').hide();
                                },
                                function (err) {
                                    console.log(err);
                                },
                            );
                    },
                    false,
                );

                if (file) {
                    reader.readAsDataURL(file);
                }
            }
        } else {
            $('#loading').hide();
            alert('Please upload an Image!');
        }
    });

    $('#amountBtn').on('click', (e) => {
        if (imageData !== null) {
            if (isReceipt) {
                $('#loading').show();
                workflowId = 'VTR';
                app.workflow.predict(workflowId, { base64: imageData }).then(
                    function (response) {
                        $('#loading').hide();
                        let possibleAmount = '<h1>The total cost is probably:</h1>';
                        let ArrayOfResponses = response.results[0].outputs[2].data.regions;
                        ArrayOfResponses.forEach(function (output) {
                            if (output.data.text.raw.includes('$', '.')) {
                                possibleAmount += `<br><h1>${output.data.text.raw}</h1>`;
                            }
                        });
                        $('.cost').html(possibleAmount);
                    },
                    function (err) {
                        console.log(err);
                    },
                );
            } else {
                alert('Image uploaded was not a receipt!');
            }
        } else alert('Nothing was uploaded!');
    });
});

function uploadImagewTag(image) {
    app.inputs
        .create({
            base64: image,
            concepts: [
                {
                    id: 'receipt',
                    value: true,
                },
            ],
        })
        .then((response) => console.log(response));
}

function reset() {
    $('.analysis').html('');
    $('.cost').html('');
}
